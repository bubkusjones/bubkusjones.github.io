A Pen created at CodePen.io. You can find this one at http://codepen.io/jamorris/pen/EKjygw.

 This is not the greatest page in the world, this is just a tribute. 